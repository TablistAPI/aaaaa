var chatbox = {

    template: `
		<div class="card card-chatbox" id="chatbox">
			<div class="card-header header-theme">
				{chatboxTitle}
			</div>
			<div class="card-body">
				<div class="list chat-list" id="chatLog">
					{chatboxLoading}
				</div>
			</div>
			<div class="card-footer">
				<form action="" class="disabled" id="chatForm" autocomplete="off">
					<div class="input-group">
   						<input type="text" class="form-control" id="chatInput" placeholder="{chatboxMessagePlaceholder}" />
   						<span class="input-group-btn">
								<button type="submit" class="btn btn-theme float-right" id="chatInputSubmit">
									<i class="fas fa-share fa-fw"></i>
								</button>
   						</span>
					</div>
				</form>
			</div>
		</div>
	`,

    itemTemplate: `
		<div class="row chat-item" id="chatMessage-{messageId}">
			<div class="col-2 col-md-1">
				<a href="{authorProfile}"><img src="{authorAvatar}" class="avatar-img" style="max-width: 100%"></a>
			</div>
			<div class="col-10 col-md-11">
				<a href="{authorProfile}" style="{authorStyle}">{authorUsername}</a><div class="float-right">{messageActions}</div>
				<small title="{messageTimeFull}">{messageTime}</small><br />{messageContent}
			</div>
		</div>
	`,

    elements: {
        containerTop: '#chatbox-top',
        containerBottom: '#chatbox-bottom',
        root: '#chatbox',
        log: '#chatbox #chatLog',
        form: '#chatbox #chatForm',
        input: '#chatbox #chatInput'
    },

    style: ``

}